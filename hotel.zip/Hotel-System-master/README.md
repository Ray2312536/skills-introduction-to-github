# Hotels_Server
<h1>SEHO自助酒店终端管理系统</h1>

**简化目前酒店入住繁琐的酒店登记退房过程。用户自助入住，一键退房，营业额统计，权限管理，团队入住，门锁和制卡功能，通过应用程序或者前台页面预定酒店，搭配一个酒店管理系统进行系统交互，搭载在微信公众号平台，微信小程序，安卓和IOS平台。**

<ul><h3>SEHO自助酒店管理系统常见功能：</h3>
<li>用户自助入住</li>
<li>一键退房</li>
<li>封装PDO数据库操作类，实现增删改查等等常见功能，调用简单</li>
<li>随机酒店推荐策略</li>
</ul>


<h3>效果截图</h3>

![首页图](https://m.qpic.cn/psb?/V10RPqxf0KYExF/hb6Q7IV1EEebZX5BOT1ikxG3gTuW9*Jq98kDHSR.wTU!/b/dLwAAAAAAAAA&bo=sAQgAwAAAAARB6c!&rf=viewer_4 "首页图")

<p>ToDo：后期可能会实现MVC框架优化。客户端接口想实现缓存出来，当客户端请求的数据存在于缓存的时候直接从缓存中读取。</p>

如果有不懂的地方可以加入QQ交流群讨论：<a target="_blank" href="#">**xxxxxxx**</a>。这个QQ群讨论技术范围包括：iOS、H5混合开发、前端开发、PHP开发，欢迎大家讨论技术。



<h3>效果截图</h3>

<!-- ![App效果图](https://raw.githubusercontent.com/FantasticLBP/Hotels/master/1.gif "这是App的效果图") -->



## 本项目包含功能为后端，如有需要配套功能更全、更完整的客户端或者商业合作请联系本人（QQ/微信：20043675）


