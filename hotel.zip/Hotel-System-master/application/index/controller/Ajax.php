<?php
namespace app\index\controller;
use think\Controller;
use think\Request;

class Ajax extends Controller
{
    


    public function index(){

    	echo "2222";
    }


	
	 
	







	
	 
	
 

}
